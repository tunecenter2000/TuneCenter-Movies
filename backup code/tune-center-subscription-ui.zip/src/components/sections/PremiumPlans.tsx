import React from 'react';
import { motion } from 'framer-motion';
import { PlanProps } from '../../utils/types';
import { PREMIUM_PLANS } from '../../utils/constants';
import { formatPrice } from '../../utils/helpers';
import Card from '../shared/Card';
import Button from '../shared/Button';

interface PremiumPlansProps {
  onSelectPlan: (planId: string) => void;
}

const PremiumPlans: React.FC<PremiumPlansProps> = ({ onSelectPlan }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };
  
  return (
    <section id="pricing" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Choose Your Perfect Plan
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Select the plan that works best for you. Downgrade or upgrade at any time.
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {PREMIUM_PLANS.map((plan) => (
            <PlanCard 
              key={plan.id} 
              plan={plan} 
              onSelect={() => onSelectPlan(plan.id)}
              variants={itemVariants}
            />
          ))}
        </motion.div>
        
        <div className="mt-16 text-center">
          <p className="text-gray-400 mb-4">
            All plans include a free trial. Cancel anytime.
          </p>
          <p className="text-sm text-gray-500">
            HD (720p), Full HD (1080p), Ultra HD (4K) and HDR availability subject to your internet service and device capabilities. Not all content is available in all resolutions.
          </p>
        </div>
      </div>
    </section>
  );
};

interface PlanCardProps {
  plan: PlanProps;
  onSelect: () => void;
  variants: any;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, onSelect, variants }) => {
  return (
    <motion.div variants={variants}>
      <Card 
        className={`h-full flex flex-col ${
          plan.isPopular ? 'border-2 border-[#E50914] relative' : ''
        }`}
      >
        {plan.isPopular && (
          <div className="absolute top-0 right-0 bg-[#E50914] text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
            MOST POPULAR
          </div>
        )}
        
        <div className="p-6 flex-1 flex flex-col">
          <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
          <div className="mb-6">
            <span className="text-3xl font-bold text-white">{formatPrice(plan.price)}</span>
            <span className="text-gray-400">/month</span>
          </div>
          
          <ul className="space-y-3 mb-8 flex-1">
            {plan.features.map((feature, index) => (
              <li key={index} className="flex items-start">
                <svg 
                  className="h-5 w-5 text-green-500 mr-2 mt-0.5" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M5 13l4 4L19 7" 
                  />
                </svg>
                <span className="text-gray-300">{feature}</span>
              </li>
            ))}
          </ul>
          
          <Button 
            variant={plan.isPopular ? "primary" : "outline"} 
            fullWidth 
            onClick={onSelect}
          >
            Choose Plan
          </Button>
        </div>
      </Card>
    </motion.div>
  );
};

export default PremiumPlans;